README LABORATOR 1

- schimbare culoare fundal folosind tasta F

- schimbare obiect aflat la pozitia (-3, 0, 0) in alt obiect folosind tasta C

- miscare obiect aflat la pozitia (3, 0, -5): pe axa Ox folosind A si D, 
pe axa Oy folosind W si S, pe axa Oz folosind Q si E, rotire in jurul 
punctului (0, 0) folosind tasta R (apasare continua).
