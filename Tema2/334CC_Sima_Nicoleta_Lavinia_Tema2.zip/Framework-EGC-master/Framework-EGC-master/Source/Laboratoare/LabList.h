#pragma once

#include <Laboratoare/Laborator1/Laborator1.h>
#include <Laboratoare/Laborator2/Laborator2.h>
#include <Laboratoare/Laborator3/Laborator3.h>
#include <Laboratoare/Laborator3/Laborator3_Vis2D.h>
#include <Laboratoare/Laborator4/Laborator4.h>
#include <Laboratoare/Laborator5/Laborator5.h>
#include <Laboratoare/Laborator6/Laborator6.h>
#include <Laboratoare/Laborator7/Laborator7.h>
#include <Laboratoare/Laborator8/Laborator8.h>
#include <Laboratoare/Laborator9/Laborator9.h>
#include <Laboratoare/Tema1/Tema1.h>
#include <Laboratoare/Tema2/Tema2.h>