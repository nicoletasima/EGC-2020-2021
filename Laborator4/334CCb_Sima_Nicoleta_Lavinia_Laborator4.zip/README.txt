	BONUS MISCARE SOARE:
	Tastele UP, DOWN, LEFT SI RIGHT (sageti) pentru deplasare soare pe Ox, Oy. 
	Tastele M si N pentru deplasare fata-spate pe Oz.